Starting from DSTU, this project only contains the generated class files representing the Fhir Resources and datatypes.

All other functionality (parsing, serializing, profile validation, etc) is part of the open-source FHIR
support library which can be obtained by NuGet (look for Hl7.Fhir, currently the stable September 2013 WGM version). You can find the source code for the support API at http://github.com/ewoutkramer/fhir-net-api.
