package org.hl7.fhir.instance.model;

public class Constants {

  public final static String VERSION = "0.2.1";
  public final static String REVISION = "????";
  public final static String DATE = "Fri Jun 06 13:25:27 UTC 2014";
}
