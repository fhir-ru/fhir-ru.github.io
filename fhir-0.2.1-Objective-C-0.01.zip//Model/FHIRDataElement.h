﻿/*
  Copyright (c) 2011-2014, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Fri, Jun 6, 2014 13:25+0000 for FHIR v0.2.1
 */
/*
 * Resource data element
 *
 * [FhirResource("DataElement")]
 * [Serializable]
 */

#import "FHIRBaseResource.h"


@class FHIRString;
@class FHIRContact;
@class FHIRCode;
@class FHIRDateTime;
@class FHIRCodeableConcept;
@class FHIRCoding;
@class FHIRElement;
@class FHIRInteger;
@class FHIRDataElementBindingComponent;
@class FHIRDataElementMappingComponent;

@interface FHIRDataElement : FHIRBaseResource

/*
 * The lifecycle status of a Resource data element
 */
typedef enum 
{
    kResourceDataElementStatusDraft, // This data element is still under development.
    kResourceDataElementStatusActive, // This data element is ready for normal use.
    kResourceDataElementStatusRetired, // This data element has been deprecated, withdrawn or superseded and should no longer be used.
} kResourceDataElementStatus;

/*
 * Logical id to reference this data element
 */
@property (nonatomic, strong) FHIRString *identifierElement;

@property (nonatomic, strong) NSString *identifier;

/*
 * Logical id for this version of the data element
 */
@property (nonatomic, strong) FHIRString *versionElement;

@property (nonatomic, strong) NSString *version;

/*
 * Name of the publisher (Organization or individual)
 */
@property (nonatomic, strong) FHIRString *publisherElement;

@property (nonatomic, strong) NSString *publisher;

/*
 * Contact information of the publisher
 */
@property (nonatomic, strong) NSArray/*<Contact>*/ *telecom;

/*
 * draft | active | retired
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *statusElement;

@property (nonatomic) kResourceDataElementStatus status;

/*
 * Date for this version of the data element
 */
@property (nonatomic, strong) FHIRDateTime *dateElement;

@property (nonatomic, strong) NSString *date;

/*
 * Descriptive label for this element definition
 */
@property (nonatomic, strong) FHIRString *nameElement;

@property (nonatomic, strong) NSString *name;

/*
 * Assist with indexing and finding
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *category;

/*
 * Identifying concept
 */
@property (nonatomic, strong) NSArray/*<Coding>*/ *code;

/*
 * How to ask for element
 */
@property (nonatomic, strong) FHIRString *questionElement;

@property (nonatomic, strong) NSString *question;

/*
 * Full formal definition in human language
 */
@property (nonatomic, strong) FHIRString *definitionElement;

@property (nonatomic, strong) NSString *definition;

/*
 * Comments about the use of this element
 */
@property (nonatomic, strong) FHIRString *commentsElement;

@property (nonatomic, strong) NSString *comments;

/*
 * Why is this needed?
 */
@property (nonatomic, strong) FHIRString *requirementsElement;

@property (nonatomic, strong) NSString *requirements;

/*
 * Other names
 */
@property (nonatomic, strong) NSArray/*<string>*/ *synonymElement;

@property (nonatomic, strong) NSArray /*<NSString>*/ *synonym;

/*
 * Name of Data type
 */
@property (nonatomic, strong) FHIRCode *typeElement;

@property (nonatomic, strong) NSString *type;

/*
 * Example value: [as defined for type]
 */
@property (nonatomic, strong) FHIRElement *example;

/*
 * Length for strings
 */
@property (nonatomic, strong) FHIRInteger *maxLengthElement;

@property (nonatomic, strong) NSNumber *maxLength;

/*
 * Units to use for measured value
 */
@property (nonatomic, strong) FHIRCodeableConcept *units;

/*
 * ValueSet details if this is coded
 */
@property (nonatomic, strong) FHIRDataElementBindingComponent *binding;

/*
 * Map element to another set of definitions
 */
@property (nonatomic, strong) NSArray/*<DataElementMappingComponent>*/ *mapping;

- (FHIRErrorList *)validate;

@end
