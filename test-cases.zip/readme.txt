Test Cases in this archive:

patch\json-patch-tests.json = Tests for JSON Patch
patch\xml-patch-tests.xml = Tests for XML Patch
patch\fhir-path-tests.xml = Tests for FHIR Path based Patch 
validation-examples\* = Basic tests for FHIR validators
valuesets\* = Test cases for basic value set expansion

